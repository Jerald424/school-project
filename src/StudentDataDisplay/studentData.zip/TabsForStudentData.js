import React from "react";
import { Tab, TabList, TabPanel, Tabs } from "react-tabs";
import Family from "./Family/Family";

export default function TabsForStudentData({
  doorDetail,
  place,
  street,
  city,
  taluk,
  district,
  state,
  pincode,
  country,
}) {
  return (
    <div className='tab-total'>
      <Tabs>
        <TabList>
          <Tab>Adress</Tab>
          <Tab>Family</Tab>
          <Tab>Social Media</Tab>
        </TabList>
        <TabPanel>
          <div className='student-data-tabs'>
            <div className='table-first-key-value'>
              <div className='table-first-key'>
                <p>Door Detail</p>
                <p>Street</p>
                <p>Place</p>
                <p>City</p>
                <p>Taluk</p>
              </div>
              <div className='table-first-value'>
                <p>{doorDetail}</p>
                <p>{street}</p>
                <p>{place}</p>
                <p>{city}</p>
                <p>{taluk}</p>
              </div>
            </div>
            <div className='table-second-key-value'>
              <div className='table-second-key'>
                <p>District</p>
                <p>State</p>
                <p>Pincode</p>
                <p>Country</p>
              </div>
              <div className='table-second-value'>
                <p>{district}</p>
                <p>{state}</p>
                <p>{pincode}</p>
                <p>{taluk}</p>
              </div>
            </div>
          </div>
        </TabPanel>
        <TabPanel>
          <Family />
        </TabPanel>
        <TabPanel>
          <p>hello social</p>
        </TabPanel>
      </Tabs>
    </div>
  );
}
