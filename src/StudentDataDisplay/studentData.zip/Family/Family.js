import React from "react";

export default function Family() {
  return <div>Family</div>;
}
