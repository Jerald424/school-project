export function Config() {
  var envType = process.env.NODE_ENV;
  var session_id = {};
  if (envType === "development") {
    session_id = {
      "X-Openerp-Session-Id": "3b5c691b4c9c31019f037766710b0d936f9e9975",
    };
  }
  const axiosInstance = {
    baseURL: "/api/portal",
    timeout: 10000,
    headers: {
      "Content-Type": "application/json",
      accept: "*/*",
      ...session_id,
    },
  };
  return axiosInstance;
}
